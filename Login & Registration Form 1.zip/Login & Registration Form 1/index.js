function redirectToAnotherPage() {
 
    window.location.href = "register.html";
}
